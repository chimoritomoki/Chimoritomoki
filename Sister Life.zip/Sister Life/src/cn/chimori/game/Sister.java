package cn.chimori.game;

import java.util.Random;

import cn.chimoro.main.Main;

//����
public class Sister {
	public static final int HAPPY_BAD = 0;
	public static final int HAPPY_COMMON = 1;
	public static final int HAPPY_GOOD = 2;
	public static final int HAPPY_VERYGOOD = 3;
	
	public static final int SEX_BAD = 0;
	public static final int SEX_COMMON = 1;
	public static final int SEX_GOOD = 2;
	public static final int SEX_VERYGOOD = 3;
	
	public int happy;   //����
	private int trust;   //����
	public int sexFeel; //�˷�
	private int sexuality;//����
	
	private int sexGood;
	private int sexBad;
	public int sleep; //˯��ֵ
	
	public int trust0;
	public int sexuality0;
	public int sexualitybad;
	public Sister() {
		Random ran = new Random();
		trust = ran.nextInt(100);
		happy = HAPPY_COMMON;
		sexFeel = SEX_COMMON;
		sexuality = ran.nextInt(100);;
		
		sexGood = 0;   //263Ϊ��
		sexBad = 0;  //263Ϊ��
		
		sleep = 600;
		trust0 = 1;
		sexuality0 = 1;
		sexualitybad = 5;
	}
	public void setSexGoodBad() {
		sexGood = 0;
		sexBad = 0;
	}
	public void sisterUpDate () {
		if(trust<120) {
			trust0 = 150;
		}
		if(trust>=200) {
			trust0 = 100;
		}
		if(trust>=400) {
			trust0 = 50;
		}
		if(trust>=600) {
			trust0 = 10;
		}
		if(sexuality<120) {
			sexuality0 = 1;
		}
		if(sexuality>=200) {
			sexuality0 = 2;
		}
		if(sexuality>=400) {
			sexuality0 = 3;
		}
		if(sexuality>=600) {
			sexuality0 = 4;
		}
		if(sexuality<120) {
			sexualitybad = 4;
		}
		if(sexuality>=120) {
			sexualitybad = 3;
		}
		if(sexuality>=200) {
			sexualitybad = 2;
		}
		if(sexuality>=300) {
			sexualitybad = 1;
		}
	}

	@Override
	public String toString() {
		return "Sister [happy=" + happy + ", trust=" + trust + ", sexFeel=" + sexFeel + ", sexuality=" + sexuality
				+ ", sexGood=" + sexGood + ", sexBad=" + sexBad + ", sleep=" + sleep + ", trust0=" + trust0
				+ ", sexuality0=" + sexuality0 + "]";
	}
	public void setSexBad(int i) {
		sexBad = i;
	}
	public void setSexGood(int i) {
		sexGood = i;
	}
	public void setaddSexGood(int i) {
		sexGood += i;
	}
	public void setSubSexGood(int i) {
		sexGood -= i;
	}
	public void setaddSexBad(int i) {
		sexBad += i;
	}
	public void setsubSexBad(int i) {
		sexBad -= i;
	}
	public int getSexGood() {
		return sexGood;
	}
	public int getSexBad() {
		return sexBad;
	}
	public void setSexUality(int i) {
		sexuality+=i;
	}
	public void setSubSexUality(int i) {
		sexuality-=i;
	}
	public void setTrust(int i) {
		trust+=i;
	}
	public void setSubTrust(int i) {
		trust-=i;
	}
	public int getTrust() {
		return trust;
	}
	public int getSexuality() {
		return sexuality;
	}
	public void setLostHappy() {
		if(happy<3 && happy>0) {
			happy -= 1;
		}
	}
	public void setNewDaySexFeel(int i) {
		sexFeel = i;
	}
	public void setNewDayHappy(int i) {
		happy = i;
	}
	public void setHappy() {
		if(happy<3) {
			happy += 1;
		}
	}
	public String getHappy() {
		switch(happy) {
		case HAPPY_BAD:
			return "������";
		case HAPPY_COMMON:
			return "һ��";
		case HAPPY_GOOD:
			return "����";
		case HAPPY_VERYGOOD:
			return "�ܸ���";
		}
		return null;
	}
	public String getSexFeel() {
		switch(sexFeel) {
		case SEX_BAD:
			return "�۸�";
		case SEX_COMMON:
			return "һ��";
		case SEX_GOOD:
			return "����";
		case SEX_VERYGOOD:
			return "������";
		}
		return null;
	}
	public int clickSister(int x,int y) {
		if(x>=87 && x<=336 & y>=241 && y<=361) {
			return Main.GAME_SAY;
		}
		return 2;
	}
	public int fuck(int x,int y) {//����״̬
		if(x>=36 && x<=171 & y>=390 && y<=448) {
			return Main.OPEN_LEG;
		}
		if(x>=36 && x<=171 & y>=479 && y<=536) {
			return Main.FUCKING;//�鶯
		}
		if(x>=859 && x<=985 & y>=496 && y<=551) {
			return Main.MORNING;
		}
		return Main.FUCK;//����
	}
	public int sexClick01(int x,int y) {//û����״̬
		if(x>=36 && x<=171 & y>=390 && y<=448) {
			return Main.TOUCH_HEAD;
		}
		if(x>=36 && x<=171 & y>=479 && y<=536) {
			this.sexBad += trust0;
			return Main.TAKE_BRIEFS;//���ڿ�
		}
		if(x>=859 && x<=985 & y>=496 && y<=551) {
			return Main.MORNING;
		}
		return Main.SEX_QUILT;//�ѱ���
	}
		public int sexClick03(int x,int y) {//�ſ��� 
			if(x>=36 && x<=171 & y>=390 && y<=448) {
				return Main.TOUCH_HEAD_03;
			}
			if(x>=36 && x<=171 & y>=479 && y<=536) {
				this.sexBad += trust0;
				return Main.FUCK;//����
			}
			if(x>=859 && x<=985 & y>=496 && y<=551) {
				return Main.MORNING;
			}
			return Main.OPEN_LEG;//�ص�����
	}
	public int sexClick02(int x,int y) {//���ڿ�
		if(x>=36 && x<=171 & y>=390 && y<=448) {
			return Main.TOUCH_HEAD_02;
		}
		if(x>=36 && x<=171 & y>=479 && y<=536) {
			this.sexBad += trust0;
			return Main.OPEN_LEG;//�ſ���
		}
		if(x>=859 && x<=985 & y>=496 && y<=551) {
			return Main.MORNING;
		}
		return Main.TAKE_BRIEFS;//�ѱ���
	}
	public int sexClick(int x,int y) {
		if(x>=36 && x<=171 & y>=390 && y<=448) {
			return Main.MORNING;
		}
		if(x>=36 && x<=171 & y>=479 && y<=536) {
			return Main.SEX_QUILT;
		}
		return Main.GAME_SEX;
	}
	public int clickmenu(int x,int y) {
		if(x>=422 && x<=596 & y>=234 && y<=262) {
			return 5;
		}
		if(x>=422 && x<=596 & y>=265 && y<=291) {
			return Main.GAME_MENU_TEA;
		}
		if(x>=422 && x<=596 & y>=291 && y<=318) {
			return Main.GAME_MENU_SHOWER;
		}
		if(x>=422 && x<=596 & y>=318 && y<=343) {
			return Main.GAME_MENU_SHOP;
		}
		if(x>=422 && x<=596 & y>=343 && y<=371) {
			return Main.GAME_MENU_SLEEP;
		}
		return 2;
	}
	public int clickmenuTwo(int x,int y) {
		if(x>=422 && x<=596 & y>=234 && y<=262) {
			return 6;
		}
		if(x>=438 && x<=585 & y>=265 && y<=291) {
			return Main.GAME_COMMUNICATION_02;
		}
		if(x>=437 && x<=585 & y>=293 && y<=318) {
			return Main.GAME_COMMUNICATION_03;
		}
		if(x>=422 && x<=596 & y>=323 && y<=344) {
			return Main.GAME_COMMUNICATION_04;
		}
		return Main.GAME_SAY;
	}
	public int clickmenuThree(int x,int y) {
		if(x>=422 && x<=596 & y>=234 && y<=262) {
			return 7;
		}
		if(x>=444 && x<=570 & y>=288 && y<=315) {
			return Main.GAME_COMMUNICATION_01_03;
		}
		if(x>=446 && x<=572 & y>=264 && y<=288) {
			return Main.GAME_COMMUNICATION_01_02;
		}
		return 5;
	}
	public int clickMenuPlayGame(int x,int y) {
		if(x>=422 && x<=596 & y>=234 && y<=262) {
			return Main.GAME_COMMUNICATION_03_01;
		}
		if(x>=444 && x<=570 & y>=288 && y<=315) {
			return Main.GAME_COMMUNICATION_03_02;
		}
		if(x>=446 && x<=572 & y>=264 && y<=288) {
			return Main.GAME_COMMUNICATION_03_03;
		}
		return 5;
	}
}
