package cn.chimori.game;
//���
public class Player {
	private int money;
	private int lifeEnergy;
	private int sexExciting;
	private int sexShoot; 
	public Player() {
		money = 10000;
		lifeEnergy = 50;
		sexExciting = 0;
		sexShoot = 2;
	}
	public void setSexExciting(int i) {
		sexExciting = i;
	}
	public void setSexShoot(int i) {
		sexShoot = i;
	}
	public void setSubSexShoot(int i) {
		sexShoot -= i;
	}
	public void setAddSexExciting(int i) {
		sexExciting += i;
	}
	public int getsexExciting() {
		return sexExciting;
	}
	public int getMoney() {
		return money;
	}
	public int getlifeEnergy() {
		return lifeEnergy;
	}
	public int getSexshoot() {
		return sexShoot; 
	}
	public void setlifeEnetgy(int i) {
		lifeEnergy-=i;
	}
	public void setaddlifeEnetgy(int i) {
		lifeEnergy+=i;
	}
}
