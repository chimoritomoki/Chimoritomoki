package cn.chimori.game;

public class Time {
	private int shower;
	private int drinkTea;
	private int H;
	private int M;
	private int W;
	private int day;
	public Time() {
		shower = 0;
		drinkTea = 0;
		W = 1;
		H = 19;
		M = 0;
		day = 0;
	}
	public void setM(int i) {
		M = i;
	}
	public void setshower(int i) {
		shower+=i;
	}
	public int getshower() {
		return shower;
	}
	public void setDrinkTea(int i) {
		drinkTea+=i;
	}
	public int getdrinkTea() {
		return drinkTea;
	}
	public void runTime() {
		if(M>=60) {
			H++;
			M=0;
		}
		if(H>=24) {
			drinkTea=0;
			shower=0;
			H=0;
			W++;
			day++;
		}
		if(W>7) {
			W=1;
		}
	}
	public void setH(int i) {
		H = i;
	}
	public int getDay() {
		return day;
	}
	public void useTime(int i) {
		M += i;
	}
	public int getHour() {
		return H;
	}
	public int getMinute() {
		return M;
	}
	public int getWeek() {
		return W;
	}
}
