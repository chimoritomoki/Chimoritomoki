package cn.chimori.images;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

//ͼƬ������
public class Images {
	public static BufferedImage cover;
	public static BufferedImage start;
	public static BufferedImage bg_001_01;
	public static BufferedImage bg_001_02;
	public static BufferedImage bg_001_03;
	public static BufferedImage bg_001_04;
	public static BufferedImage bg_001_05;
	public static BufferedImage sistersay;
	public static BufferedImage nomanroom;
	public static BufferedImage sistermessage;
	public static BufferedImage sistersay01;
	public static BufferedImage menu;
	public static BufferedImage menu_01;
	public static BufferedImage menu_01_01;
	public static BufferedImage menu_01_01_01;
	public static BufferedImage menu_01_01_02;
	public static BufferedImage menu_01_01_03;
	public static BufferedImage tv;
	public static BufferedImage playgame;
	public static BufferedImage playgame_H;
	public static BufferedImage drinktea; 
	public static BufferedImage seepenis; 
	public static BufferedImage shower; 
	public static BufferedImage shower01; 
	public static BufferedImage sleep; 
	public static BufferedImage sleeping; 
	public static BufferedImage sleeping2; 
	public static BufferedImage sex; 
	public static BufferedImage sex_01; 
	public static BufferedImage morning; 
	public static BufferedImage morning_go; 
	public static BufferedImage morning_go01; 
	public static BufferedImage morning_go02; 
	public static BufferedImage morning_go03; 
	public static BufferedImage makesex_01; 
	public static BufferedImage good; 
	public static BufferedImage bad; 
	public static BufferedImage touchhead; 
	public static BufferedImage takebriefs; 
	public static BufferedImage bediscovered; 
	public static BufferedImage badmorning; 
	public static BufferedImage[] sleeptype; 
	public static BufferedImage justtouchhead; 
	public static BufferedImage sex_03; 
	public static BufferedImage sex_04; 
	public static BufferedImage[] sex_05;
	public static BufferedImage sistermax;
	public static BufferedImage playershoot;
	public static BufferedImage tolate;
	public static BufferedImage full;
	public static BufferedImage start_01;
	public static BufferedImage start_02;
	public static BufferedImage start_03;
	public static BufferedImage start_04;
	public static BufferedImage start_05;
	public static BufferedImage start_06;
	
	static {
		full = loadImage("full.png"); 
		cover = loadImage("gamecover.jpg");
		start = loadImage("gamestart.png");
		bg_001_01 = loadImage("bg_001_01.png");
		bg_001_02 = loadImage("bg_001_02.jpg");
		bg_001_03 = loadImage("bg_001_03.jpg");
		bg_001_04 = loadImage("bg_001_04.jpg");
		bg_001_05 = loadImage("bg_001_05.jpg");
		sistersay = loadImage("sistersay.png");
		nomanroom = loadImage("bg_001_01.jpg");
		sistermessage = loadImage("sistermessage.png");
		sistersay01 = loadImage("sistersay01.png");
		menu = loadImage("menu.png");
		menu_01 = loadImage("menu_01.png");
		menu_01_01 = loadImage("menu_01_01.png");
		menu_01_01_01 = loadImage("menu_01_01_01.png");
		menu_01_01_02 = loadImage("menu_01_01_02.png");
		menu_01_01_03 = loadImage("menu_01_01_03.png");
		tv = loadImage("tv.png");
		playgame = loadImage("playgame.png");
		playgame_H = loadImage("playgame_H.png");
		drinktea = loadImage("drinktea.png");
		shower = loadImage("shower.png");
		shower01 = loadImage("shower01.png");
		seepenis = loadImage("seePenis.png");
		sleep = loadImage("sleep.png");
		sleeping = loadImage("sleeping.jpg");
		sleeping2 = loadImage("sleeping2.png");
		sex = loadImage("sex.png");
		sex_01 = loadImage("sex_01.png");
		morning = loadImage("morning.png");
		morning_go = loadImage("morning_go.png");
		morning_go01 = loadImage("morning_go01.png");
		morning_go02 = loadImage("morning_go02.png");
		morning_go03 = loadImage("morning_go03.png");
		makesex_01 = loadImage("sex_02.png");
		good = loadImage("good.png");
		bad = loadImage("bad.png");
		touchhead = loadImage("touchhead.png");
		takebriefs = loadImage("takebriefs.png");
		bediscovered = loadImage("bediscovered.png");
		badmorning = loadImage("badmorning.png");
		sleeptype = new BufferedImage[5];
		for(int i=0;i<sleeptype.length;i++) {
			sleeptype[i] = loadImage("sleeptype"+i+".png");
		}
		justtouchhead = loadImage("justtouchhead.png");
		sex_03 = loadImage("sex_03.png");
		sex_04 = loadImage("sex_04.png");
		sex_05 = new BufferedImage[2];
		sex_05[0] = loadImage("sex_05_0.png");
		sex_05[1] = loadImage("sex_05_1.png");
		sistermax = loadImage("sistermax.png");
		playershoot = loadImage("playershoot.png");
		tolate = loadImage("tolate.png");
		start_01 = loadImage("start_01.png");
		start_02 = loadImage("start_02.png");
		start_03 = loadImage("start_03.png");
		start_04 = loadImage("start_04.png");
		start_05 = loadImage("start_05.png");
		start_06 = loadImage("start_06.png");
	}
	
	public	static BufferedImage loadImage(String name) {
		try {
			BufferedImage img = ImageIO.read(Images.class.getResource(name));
			return img;
		}catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException();
		}
	}
}
