package cn.chimoro.main;

import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import cn.chimori.game.*;
import javax.swing.JFrame;
import javax.swing.JPanel;

import cn.chimori.images.Images;
/**
 * Please use GBK
 * 
 * ��һ�����ű����Ϸд�Ĵ���
 * û�вο�����   д�ĺ���  ��㿴����
 * 
 * �����Ҳ���R18����Ϸ��
 * һ��ʼдһ���� ������� ����ҳС��Ϸ��
 * 
 * д��һ�㷢��   ���ӵ����������ߺ�����ô�ö��ò���
 * �ͷ�����
 * 
 * ����֮ǰ�����ձ����С����  ���ݼ�  �Ƚ��ʺ���ϰ
 * ��������ϰ��
 * 
 * �򿪿��������ˣ�������ԭ�棬��ֻд��һ������Ϸ���ݡ�
 * @author ǧɭ�Ǽo
 * 2020��7��2��17:17:32
 */
//������
public class Main extends JPanel {
	public static final int SISTER_SEX_GOOD_BAD_MAX = 263;
	public static final int GAME_WIDTH = 1024;
	public static final int GAME_HEIGHT = 576;
	public static final int TIME_SPEED = 12;
	
	public static final int GAME_COVER = 0;
	public static final int GAME_START = 1;
	public static final int GAME_RUNNING = 2;
	public static final int GAME_SAY = 4;
	public static final int GAME_COMMUNICATION = 5;
	public static final int GAME_COMMUNICATION_01 = 6;
	public static final int GAME_COMMUNICATION_01_01 = 7;
	public static final int GAME_COMMUNICATION_01_02  = 8;
	public static final int GAME_COMMUNICATION_01_03  = 9;
	public static final int GAME_COMMUNICATION_02  = 10;
	public static final int GAME_COMMUNICATION_03  = 11;
	public static final int GAME_COMMUNICATION_03_01  = 13;
	public static final int GAME_COMMUNICATION_03_02  = 14;
	public static final int GAME_COMMUNICATION_03_03  = 15;
	public static final int GAME_COMMUNICATION_04  = 12;
	public static final int GAME_MENU_TEA  = 16;
	public static final int GAME_MENU_SHOWER  = 17;
	public static final int GAME_MENU_SHOWER_01  = 20;
	public static final int GAME_MENU_SHOWER_02  = 21;
	public static final int GAME_MENU_SHOP  = 18;
	public static final int GAME_MENU_SLEEP  = 19;
	public static final int GAME_NOMOVE  = 22;
	public static final int GAME_SLEEPING  = 23;
	public static final int MORNING  = 25;
	public static final int MORNING_GO  = 27;
	public static final int MORNING_GO_01  = 28;
	public static final int MORNING_GO_02  = 29;
	public static final int MORNING_GO_03  = 30;
	public static final int NO_TIME  = 33;
	
	public static final int START_01  = 50;
	public static final int START_02  = 51;
	public static final int START_03  = 52;
	public static final int START_04  = 53;
	public static final int START_05  = 54;
	public static final int START_06  = 55;
	
	public static final int GAME_SEX  = 300;
	public static final int SEX_QUILT  = 301;
	public static final int TOUCH_HEAD  = 302;
	public static final int TAKE_BRIEFS  = 303;
	public static final int BE_DISCOVERED   = 304;
	public static final int BAD_MORNING   = 305;
	public static final int TOUCH_HEAD_02   = 306;
	public static final int OPEN_LEG   = 307;
	public static final int TOUCH_HEAD_03   = 308;
	public static final int FUCK   = 309;
	public static final int FUCKING   = 310;
	public static final int FULL   = 311;

	public static final int NO   = 100;
	public static final int MAX = 101;
	
	public static final int PLAYER_NO   = 200;
	public static final int PLAYER_MAX = 201;
	
	private int state = GAME_COVER;
	private int sisterState = NO;
	private int playerState = NO;

	
	
	private Player player = new Player();
	private Sister sister = new Sister();
	private Time t = new Time();
	public static BufferedImage sleep;
	
	Random ran = new Random();
	private int timeIndex = 0;
	private int maxImageIndex = 0;
	private int maxPlayerImageIndex =0;
	public void paint(Graphics g) {
		switch(state) {
		case START_01:
			g.drawImage(Images.start_01, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case START_02:
			g.drawImage(Images.start_02, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case START_03:
			g.drawImage(Images.start_03, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case START_04:
			g.drawImage(Images.start_04, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case START_05:
			g.drawImage(Images.start_05, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case START_06:
			g.drawImage(Images.start_06, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case FULL:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.full, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case FUCKING://����
			timeIndex++;
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.good, 0,306-sister.getSexGood(),null);
			g.drawImage(Images.bad, 0,306-sister.getSexBad(),null);
			if(timeIndex%200>=100) {
				g.drawImage(Images.sex_05[1], 0, 0, null);
			}else {
				g.drawImage(Images.sex_05[0], 0, 0, null);
			}
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawString("�侫�ȣ�"+player.getsexExciting()+"%", 900, 20);
			if(timeIndex%100==0) {
				t.useTime(2);//ʹ��ʱ��
				player.setAddSexExciting(3);//�侫ֵ����
				sister.setaddSexGood(sister.sexuality0*2);
				sister.setaddSexBad(sister.sexualitybad*2);
				sister.sleep-=50;//�������Ѷ�
			}
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			break;
		case FUCK://����
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.good, 0,306-sister.getSexGood(),null);
			g.drawImage(Images.bad, 0,306-sister.getSexBad(),null);
			g.drawImage(Images.sex_04, 0, 0, null);
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case TOUCH_HEAD_03://�ſ�����ͷ
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.good, 0,306-sister.getSexGood(),null);
			g.drawImage(Images.bad, 0,306-sister.getSexBad(),null);
			g.drawImage(Images.sex_03, 0,0,null);
			g.drawImage(Images.justtouchhead, 0,0,null);
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			timeIndex++;
			if(timeIndex%100==0) {
				t.useTime(2);
				sister.setsubSexBad(sister.sexuality0);
				sister.setaddSexGood(sister.sexuality0);
				sister.sleep-=10;
			}
			if(t.getHour()>=3) {
				state = NO_TIME;
			}
			if(sister.getSexGood()>=200) {
				sister.setSubSexGood(sister.sexuality0);
			}
			break;
		case TOUCH_HEAD_02://���ڿ���ͷ
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.good, 0,306-sister.getSexGood(),null);
			g.drawImage(Images.bad, 0,306-sister.getSexBad(),null);
			g.drawImage(Images.takebriefs, 0,0,null);
			g.drawImage(Images.justtouchhead, 0,0,null);
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			timeIndex++;
			if(timeIndex%100==0) {
				t.useTime(2);
				sister.setsubSexBad(sister.sexuality0);
				sister.setaddSexGood(sister.sexuality0);
				sister.sleep-=10;
			}
			if(t.getHour()>=3) {
				state = NO_TIME;
			}
			if(sister.getSexGood()>=200) {
				sister.setSubSexGood(sister.sexuality0);
			}
			break;
		case OPEN_LEG://�ſ���
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.good, 0,306-sister.getSexGood(),null);
			g.drawImage(Images.bad, 0,306-sister.getSexBad(),null);
			g.drawImage(Images.sex_03, 0,0,null);
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			break;
		case BAD_MORNING://���糿
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.badmorning, 0,0,null);
			break;
		case BE_DISCOVERED://������
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.bediscovered, 0,0,null);
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			break;
		case NO_TIME://����3��
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.tolate, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case TOUCH_HEAD://����ͷ
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.good, 0,306-sister.getSexGood(),null);
			g.drawImage(Images.bad, 0,306-sister.getSexBad(),null);
			g.drawImage(Images.touchhead, 0,0,null);
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			timeIndex++;
			if(timeIndex%100==0) {
				t.useTime(2);
				sister.setsubSexBad(sister.sexuality0);
				sister.setaddSexGood(sister.sexuality0);
				sister.sleep-=10;
			}
			if(t.getHour()>=3) {
				state = NO_TIME;
			}
			if(sister.getSexGood()>=200) {
				sister.setSubSexGood(sister.sexuality0);
			}
			break;
		case TAKE_BRIEFS://���ڿ�
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.good, 0,306-sister.getSexGood(),null);
			g.drawImage(Images.bad, 0,306-sister.getSexBad(),null);
			g.drawImage(Images.takebriefs, 0,0,null);
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			break;
		case SEX_QUILT://�ѱ���
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.good, 0,306-sister.getSexGood(),null);
			g.drawImage(Images.bad, 0,306-sister.getSexBad(),null);
			g.drawImage(Images.makesex_01, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(sleep, 0,0,null); // ��ʾ ˯��ֵ 
			break;
		case MORNING_GO_02://��˾
			g.drawImage(Images.morning_go02, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			t.useTime(3);
			if(t.getHour()>=18) {
				state = MORNING_GO_03;
			}
			break;
		case MORNING_GO_03://�ؼ�·��
			g.drawImage(Images.morning_go03, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case MORNING_GO_01://���ó���
			g.drawImage(Images.morning_go01, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			t.setM(50);
			break;
		case MORNING_GO://�ó�����
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.morning_go, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			t.setM(30);
			break;
		case MORNING://��������
			t.setH(8);
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.morning, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case GAME_SEX:
			g.drawImage(Images.sex, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.sex_01, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case GAME_SLEEPING:
			g.drawImage(Images.sleeping, 0, 0, null);
			g.drawImage(Images.sleeping2, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case GAME_NOMOVE:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawString("�ж�������", 900, 20);
			break;
		case GAME_MENU_SHOWER_01:
			if(t.getshower()==0) {
				g.drawImage(Images.nomanroom, 0, 0, null);
				g.drawImage(Images.bg_001_01, 0,0,null);
				g.drawImage(Images.sistersay, 0,0,null);
				g.drawImage(Images.shower01, 0,0,null);
				g.drawString("�ж���+15", 900, 20);
			}else {
				g.drawString("�����Ѿ�ϴ������", 900, 20);
			}
			break;
		case GAME_MENU_SHOWER_02:
			break;
		case GAME_MENU_SHOWER:
			if(t.getshower()==0) {
				g.drawImage(Images.nomanroom, 0, 0, null);
				g.drawImage(Images.sistersay, 0,0,null);
				g.drawImage(Images.shower, 0,0,null);
				g.drawImage(Images.bg_001_01, 0,0,null);
				g.drawString("�ж���+15", 900, 20);
			}else {
				g.drawString("�����Ѿ�ϴ������", 900, 20);
			}
			break;
		case GAME_MENU_SHOP:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sistersay, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawString("����δд��Ŭ��������", 900, 20);
			break;
		case GAME_MENU_SLEEP:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.sleep, 0,0,null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			if(player.getlifeEnergy()>=21) {
				if(t.getHour()==0) {
					state = GAME_SLEEPING;
				}else {
					t.useTime(1);
				}
			}else {
				if(t.getHour()==8) {
					state = MORNING;
				}else {
					t.useTime(5);
				}
			}
			break;
		case GAME_COVER:
			g.drawImage(Images.cover, 0,0,null);
			break;
		case GAME_START:
			g.drawImage(Images.start, 0,0,null);
			break;
		case GAME_RUNNING:
			g.drawImage(Images.bg_001_02, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			break;
		case GAME_SAY:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.sistersay, 0,0,null);
			g.drawImage(Images.sistermessage, 0,0,null);
			g.drawImage(Images.sistersay01, 0,0,null);
			g.drawImage(Images.menu, 0,0,null);
			g.drawString(""+sister.getTrust(), 226, 100);
			g.drawString("���飺"+sister.getHappy(), 45, 420);
			g.drawString("�жȣ�"+sister.getSexFeel(), 229, 420);
			g.drawString("���£�"+sister.getSexuality(), 239, 478);
			if(t.getDay()%5==0) {
				g.drawString("������", 62, 478);
			}else {
				g.drawString("��ȫ��", 62, 478);
			}
			break;
		case GAME_COMMUNICATION:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.sistersay, 0,0,null);
			g.drawImage(Images.menu_01, 0,0,null);
			break;
		case GAME_COMMUNICATION_01:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.sistersay, 0,0,null);
			g.drawImage(Images.menu_01_01,0,0,null);
			break;
		case GAME_COMMUNICATION_01_01:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.sistersay, 0,0,null);
			g.drawImage(Images.menu_01_01_01,0,0,null);
			g.drawString("�ж���-10", 900, 20); 
			break;
		case GAME_COMMUNICATION_01_02:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.sistersay, 0,0,null);
			g.drawImage(Images.menu_01_01_02,0,0,null);
			g.drawString("�ж���-10", 900, 20); 
			break;
		case GAME_COMMUNICATION_01_03:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.sistersay, 0,0,null);
			g.drawImage(Images.menu_01_01_03,0,0,null);
			g.drawString("�ж���-20", 900, 20); 
			break;
		case GAME_COMMUNICATION_02:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.tv,0,0,null);
			g.drawString("�ж���-10", 900, 20);
			break;
		case GAME_COMMUNICATION_03:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.playgame,0,0,null);
			break;
		case GAME_COMMUNICATION_03_01:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.playgame_H,0,0,null);
			g.drawString("�ж���-10", 900, 20);
			break;
		case GAME_COMMUNICATION_03_02:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.playgame_H,0,0,null);
			g.drawString("�ж���-10", 900, 20);
			break;
		case GAME_COMMUNICATION_03_03:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.playgame_H,0,0,null);
			g.drawString("�ж���-10", 900, 20);
			break;
		case GAME_COMMUNICATION_04:
			g.drawImage(Images.nomanroom, 0, 0, null);
			g.drawImage(Images.bg_001_01, 0,0,null);
			g.drawImage(Images.seepenis,0,0,null);
			g.drawString("�ж���-10", 900, 20);
			break;
		case GAME_MENU_TEA:
			if(t.getdrinkTea()==0) {
				g.drawImage(Images.nomanroom, 0, 0, null);
				g.drawImage(Images.bg_001_01, 0,0,null);
				g.drawImage(Images.drinktea,0,0,null);
				g.drawString("�ж���+15", 900, 20);
			}else {
				g.drawImage(Images.nomanroom, 0, 0, null);
				g.drawImage(Images.bg_001_01, 0,0,null);
				g.drawString("�����Ѿ��ȹ�����", 900, 20);
			}
			break;
		}
		if(!(state == GAME_START || state == GAME_COVER)) {
			g.drawString("����:"+t.getWeek()+"      ʱ��:"+t.getHour()+"��"+t.getMinute()+"��"+"      �ж���"+player.getlifeEnergy()+"      ����"+player.getSexshoot()+"      ���н�"+player.getMoney()+"      �����öȹ��ˣ�"+t.getDay()+"��", 20, 20);
		}
		switch(sisterState) {//���ø߳�
		case NO:
			break;
		case MAX:
			maxImageIndex++;
			g.drawImage(Images.sistermax, 0, 0, null);
			if(maxImageIndex>=500) {//ͼƬ�ӳ�
				sisterState = NO;
				maxImageIndex = 0;
			}
			break;
		}
		switch(playerState) {//�侫
		case PLAYER_NO:
			break;
		case PLAYER_MAX:
			maxPlayerImageIndex++;
			g.drawImage(Images.playershoot, 0, 0, null);
			if(maxPlayerImageIndex>=500) {//ͼƬ�ӳ�
				playerState = PLAYER_NO;
				maxPlayerImageIndex = 0;
			}
			break;
		}
	}
	public void action() {
		MouseAdapter e = new MouseAdapter() {
			public void mouseReleased(MouseEvent e){
				Sound.hit();
				switch(state) {
				case START_01:
					state = START_02;
					break;
				case START_02:
					state = START_03;
					break;
				case START_03:
					state = START_04;
					break;
				case START_04:
					state = START_05;
					break;
				case START_05:
					state = START_06;
					break;
				case START_06:
					state = GAME_RUNNING;
					break;
					
				case FULL:
					state = MORNING;
					break;
				case NO_TIME:
					state = MORNING;
					break;
				case TOUCH_HEAD_03://��������ͷ
					state = OPEN_LEG;
					break;
				case FUCKING://����
					state = FUCK;
					break;
				case FUCK://����״̬
					state = sister.fuck(e.getX(), e.getY());
					break;
				case OPEN_LEG://����
					state = sister.sexClick03(e.getX(), e.getY());
					break;
				case TOUCH_HEAD_02://���ڿ�����ͷ
					state = TAKE_BRIEFS;
					break;
				case BAD_MORNING://�����ֺ�
					t.setH(4); 
					sister.setSexGoodBad();
					sister.setLostHappy();
					sister.setSubTrust(ran.nextInt(50));
					sister.setSubSexUality(ran.nextInt(50));
					state = MORNING_GO_02;
					break;
				case BE_DISCOVERED://�����ֺ�
					state = BAD_MORNING;
					break;
				case TOUCH_HEAD://����ͷ
					state = SEX_QUILT;
					break;
				case TAKE_BRIEFS://���ڿ�
					state = sister.sexClick02(e.getX(), e.getY());
					break;
				case SEX_QUILT://�ѱ���
					state = sister.sexClick01(e.getX(), e.getY());
					break;
				case MORNING_GO_03://�ؼ�·��
					t.useTime(ran.nextInt(50));
					state = GAME_RUNNING;
					break;
				case MORNING_GO_01:
					state = MORNING_GO_02;
					break;
				case MORNING_GO_02:
					break;
				case MORNING_GO:
					state = MORNING_GO_01;
					break;
				case MORNING:
					state = MORNING_GO;
					player.setaddlifeEnetgy(ran.nextInt(30));
					break;
				case GAME_SEX://������    ȥ˯��
					sister.setaddSexBad(sister.trust0);
					state = sister.sexClick(e.getX(), e.getY());
					break;
				case GAME_SLEEPING:
					state = GAME_SEX;
					break;
				case GAME_MENU_SHOWER_01:
					if(t.getshower()==0) {
						state = GAME_SAY;
						t.useTime(30);
						player.setaddlifeEnetgy(15);
						t.setshower(1);
					}else {
						state = GAME_SAY;
					}
					break;
				case GAME_MENU_SHOWER:
					state = GAME_MENU_SHOWER_01;
					break;
				case GAME_MENU_SHOP:
					state = GAME_SAY;
					break;
				case GAME_MENU_SLEEP:
					
					break;
				case GAME_MENU_TEA:
					if(t.getdrinkTea()==0) {
						state = GAME_SAY;
						t.useTime(30);
						player.setaddlifeEnetgy(15);
						t.setDrinkTea(1);
					}else {
						state = GAME_SAY;
					}
					break;
				case GAME_COVER:
					state = GAME_START;
					break;
				case GAME_START:
					state = START_01;
					break;
				case GAME_RUNNING:
					state = sister.clickSister(e.getX(), e.getY());
					break;
				case GAME_SAY:
					state = sister.clickmenu(e.getX(), e.getY());
					break;
				case GAME_COMMUNICATION:
					state = sister.clickmenuTwo(e.getX(), e.getY());
					break;
				case GAME_NOMOVE:
					state = GAME_SAY;
					break;
				case GAME_COMMUNICATION_01:
					if(player.getlifeEnergy()>=10) {
						state = sister.clickmenuThree(e.getX(), e.getY());
					}else {
						state = GAME_NOMOVE;
					}
					break;
				case GAME_COMMUNICATION_01_01:
						state = GAME_SAY;
						sister.setTrust(ran.nextInt(10)); 
						player.setlifeEnetgy(10);
						t.useTime(10);
					break;
				case GAME_COMMUNICATION_01_02:
					state = GAME_SAY;
					sister.setTrust(ran.nextInt(5)); 
					sister.setSexUality(ran.nextInt(10));
					player.setlifeEnetgy(10);
					t.useTime(10);
					break;
				case GAME_COMMUNICATION_01_03:
					state = GAME_SAY;
					sister.setTrust(ran.nextInt(10)); 
					sister.setHappy();
					player.setlifeEnetgy(10);
					t.useTime(10);
					break;
				case GAME_COMMUNICATION_02:
					if(player.getlifeEnergy()>=10) {
						sister.setTrust(ran.nextInt(10)); 
						player.setlifeEnetgy(10);
						t.useTime(30);
						state = GAME_SAY;
					}else {
						state = GAME_NOMOVE;
					}
					break;
				case GAME_COMMUNICATION_03:
					if(player.getlifeEnergy()>=20) {
						state = sister.clickMenuPlayGame(e.getX(), e.getY());
					}else {
						state = GAME_NOMOVE;
					}
					break;
				case GAME_COMMUNICATION_03_01:
					sister.setTrust(ran.nextInt(20)); 
					player.setlifeEnetgy(20);
					t.useTime(30);
					state = GAME_SAY;
					break;
				case GAME_COMMUNICATION_03_02:
					sister.setTrust(ran.nextInt(20)); 
					sister.setSexUality(ran.nextInt(20));
					player.setlifeEnetgy(20);
					t.useTime(30);
					state = GAME_SAY;
					break;
				case GAME_COMMUNICATION_03_03:
					sister.setTrust(ran.nextInt(20)); 
					player.setlifeEnetgy(20);
					t.useTime(30);
					state = GAME_SAY;
					break;
				case GAME_COMMUNICATION_04:
					if(player.getlifeEnergy()>=10) {
						sister.setTrust(-5); 
						sister.setLostHappy();
						player.setlifeEnetgy(10);
						t.useTime(10);
						state = GAME_SAY;
					}else {
						state = GAME_NOMOVE;
					}
					break;
				}
			}
		};
		this.addMouseListener(e);
		this.addMouseMotionListener(e);
		Timer time = new Timer();
		time.schedule(new TimerTask() {
			public void run() {
				sleepSytpUpDate();  //����˯��ֵ
				beDiscoered();		//����BADֵ
				sister.sisterUpDate();	//������������
				t.runTime();		//ʱ��ϵͳ
				repaint();		
				//System.out.println(state+"  "+sister.toString());  //���������
			}
		}, TIME_SPEED,TIME_SPEED);
	}
	private int playerShootIndexTime = 0; 
	public void beDiscoered() {
		if(player.getSexshoot()==0) {//�侫ֵΪ0
			playerShootIndexTime++;
			if(playerShootIndexTime>=1000) {
				state = FULL;
				player.setSexShoot(1);
				playerShootIndexTime=0;
			}
		}
		if(state >=300 && state <=400) {
			if(t.getHour()==3) {//����ҹ������
				t.setH(4);
				state = NO_TIME;
			}

		}
		if(sister.getSexBad()<=0) {
			sister.setSexBad(0);
		}
		if(sister.getSexBad()>=SISTER_SEX_GOOD_BAD_MAX) {//žžBAD MAX�󱻷���
			state = BE_DISCOVERED;
			sister.setSexGoodBad();  //����žž����
		}
		if(t.getHour()>=12 && t.getHour()<=13) { //ÿ������
			player.setSexShoot(2);
			player.setSexExciting(0);
			sister.setSexGoodBad();    //����žž����
			sister.sleep = 600; 	   //����˯��ֵ
			sister.setNewDayHappy(ran.nextInt(3));
			sister.setNewDaySexFeel(ran.nextInt(3));
		}
		if(t.getHour()==23 && t.getMinute()==59) { //����
			if(sister.sexFeel==0) {
				sister.setSexGood(0);
			}else if(sister.sexFeel==1) {
				sister.setSexGood(30);
			}else if(sister.sexFeel==2) {
				sister.setSexGood(60);
			}else if(sister.sexFeel==3) {
				sister.setSexGood(120);
			}
		}
		
		if(sister.getSexGood()>=275) {//���ø߳�
			sister.setsubSexBad(100);
			sister.setSubSexGood(200);
			sister.setTrust(ran.nextInt(30));
			sister.setSexUality(ran.nextInt(30));
			sisterState = MAX;
		}
		if(player.getsexExciting()>=100) {//�侫���
			player.setSexExciting(0);
			sister.setaddSexBad(30);
			sister.setaddSexGood(15);
			sister.setTrust(ran.nextInt(30));
			sister.setSexUality(ran.nextInt(30));
			player.setSubSexShoot(1);
			playerState = PLAYER_MAX;
		}
		if(player.getSexshoot()==0) {//�侫����
			//TODO
		}

	}
	public void sleepSytpUpDate() {//��ʾ˯��ֵ
		if(sister.getSexBad()>=SISTER_SEX_GOOD_BAD_MAX) {
			sister.sleep-=1000;
		}else if(sister.sleep>=800) {
			sleep = Images.sleeptype[0];
		}else if(sister.sleep>=600) {
			sleep = Images.sleeptype[1];
		}else if(sister.sleep>=400) {
			sleep = Images.sleeptype[2];
		}else if(sister.sleep>=0) {
			sleep = Images.sleeptype[3];
		}else {
			sleep = Images.sleeptype[4];
		}
	}
	public static void main(String[] args) {
		Main main = new Main();
		JFrame frame = new JFrame();
		frame.add(main);
		
		frame.setSize(GAME_WIDTH,GAME_HEIGHT);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("������һ������");
		Sound.backgroud();
		main.action();
	}

}
